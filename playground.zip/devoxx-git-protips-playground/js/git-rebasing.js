$(document).on('click', '.jumbotron .btn', handleMainClick);
$(document).on('click', '.row-fluid .btn', handleSectionClick);

function handleMainClick(e) {
  e.preventDefault();
  var heading = $(e.target).closest('.jumbotron').find('h1').text();
  showModal(heading, 'That’s what you’re here for!');
}

function handleSectionClick(e) {
  e.preventDefault();
  var heading = $(e.target).closest('.span4').find('h2').text();
  showModal(heading, 'You’re about to learn how, be patient…');
}

function showModal(title, message) {
  var modal = $('#dialog');
  modal.find('.title').text(title);
  modal.find('.message').text(message);
  modal.modal('show');
}
