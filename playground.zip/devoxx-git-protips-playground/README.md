A demo repository for teaching Git rebasing
===========================================

This repo acts as a substrate we can manipulate to demonstrate various types of rebasing:

* regular
* interactive
* three-point

It contains predefined branches and specific commit sequences that let us illustrate the nominal and problematic uses of these techniques in an effective way.

For more information on our Git trainings, visit http://www.git-attitude.fr/efficient-git/
